﻿import { version } from '../../package.json';
import { Router } from 'express';
import facets from './facets';
import WordExtractor from "word-extractor";
import fs from 'fs';

export default ({ config, db }) => {
	let api = Router();
	var formMap ={
		1: {
			"nombre":"Cognoms i nom",
			"nif":"NIF",
			"fecha_nacimiento":"Data de naixement",
			"genero":"Gènere",
			"nass":"NASS",
			"discapacidad":"Discapacitat",			
		},
		2:{
			"direccion":"Adreça",
			"codigo_postal":"Codi Postal",
			"ciudad":"Població",
			"comarca":"Comarca",
			"correo":"Correu electrònic",
			"telefono":"Telèfon",
			"movil":"Telèfon mòbil",		
		},
		5:{
			"empresa_razon_social":"Raó social",
			"empresa_sector":"Sector",
			"empresa_convenio":"onveni de referència",
			"empresa_cif":"CIF",
			"empresa_ss":"a la Seguretat Social",
		},
		6:{
			"empresa_num_trabajadores":"Nre. de treballadors",
			"empresa_direccion":"Adreça del centre de treball",
			"empresa_codigo_postal":"Codi Postal",
			"empresa_poblacion":"Població",
			"empresa_comarca":"Comarca"
		}
	};
	
	function extractValueFrom(text, filterText){		
		return text.split("FORM")[0].trim().split("\u0013")[0].split("\u0007")[0].split("\r")[0];
	}
	
	api.get('/', (req, res) => {
		parse("file.doc",res);
		
	});
	
	function parse(file,res){
		var extractor = new WordExtractor();
		var extracted = extractor.extract("file.doc");
		extracted.then(function(doc) {
			var response={};
			var fullText = doc.pieces.map(piece=>piece.text).join("");
			//console.log(doc.pieces[5])
			Object.keys(formMap).forEach(index =>{
				var piece = doc.pieces[index].text;
				Object.keys(formMap[index]).forEach(field =>{
					var filterText = formMap[index][field];
					fullText = fullText.substring(fullText.indexOf(filterText)+filterText.length, fullText.length);
					//console.log(filterText, fullText.substring(0,15));
					response[field] = extractValueFrom(fullText, filterText);
				});
			});
			console.log("Cargado alumno ", response.nombre);
			res.json(response)
		});
	}

	api.post('/parser/doc', (req, res) => {
		var filePath="temp.doc"
		fs.appendFile("data22.doc", req.files.doc.data, function() {
			parse(filePath,res);
		});
		
		
	});
	
	return api;
}
